package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {

    // two EditText fields for username and password
    private EditText usernameEditText;
    private EditText passwordEditText;
    private AppDatabase db;
    // creates its own ExecutorService here instead of using DbExecutors like DataGridActivity does
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        // login and register buttons
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);

        db = AppDatabase.getDatabase(this);

        // grabs the text, trims whitespace, checks if empty
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // basic empty check - good, but no other validation happening
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.username_password_required), Toast.LENGTH_SHORT).show();
                return;
            }

            // runs the login query on a background thread
            io.execute(() -> {
                User user = db.userDao().login(username, password);
                runOnUiThread(() -> {
                    // if a matching user is found, go to DataGridActivity
                    if (user != null) {
                        startActivity(new Intent(LoginActivity.this, DataGridActivity.class));
                        finish();
                    } else {
                        // no match - show login failed toast
                        Toast.makeText(this, getString(R.string.login_failed), Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });

        // register button - lets first-time users create an account
        registerButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.username_password_required), Toast.LENGTH_SHORT).show();
                return;
            }

            io.execute(() -> {
                // uses IGNORE conflict strategy - returns -1 if username already exists
                long result = db.userDao().insertUser(new User(username, password));
                runOnUiThread(() -> {
                    if (result != -1) {
                        Toast.makeText(this, getString(R.string.registration_success), Toast.LENGTH_SHORT).show();
                    } else {
                        // username taken
                        Toast.makeText(this, getString(R.string.registration_username_exists), Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });
    }
}