package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WeightDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertWeight(WeightEntry entry);

    @Query("SELECT * FROM weights ORDER BY date DESC")
    List<WeightEntry> getAllWeights();

    @Delete
    void deleteWeight(WeightEntry entry);
}