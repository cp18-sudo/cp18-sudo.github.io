package com.example.weighttracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

// this class is doing way too much - UI, database, input parsing, goal checking all in one place
// no ViewModel, no Repository, no separation of concerns
public class DataGridActivity extends AppCompatActivity {

    private WeightAdapter adapter;
    // only data structure used is a flat ArrayList
    private List<WeightEntry> weightEntries;
    private AppDatabase db;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    // everything happens inside this one onCreate method
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // sets up a RecyclerView to display weight entries
        RecyclerView weightRecyclerView = findViewById(R.id.weightRecyclerView);
        Button addEntryButton = findViewById(R.id.addEntryButton);
        Button smsPermissionButton = findViewById(R.id.smsPermissionButton);

        db = AppDatabase.getDatabase(this);
        weightEntries = new ArrayList<>();

        // delete callback gets passed to the adapter - each row has a delete button
        adapter = new WeightAdapter(weightEntries, entry -> DbExecutors.io().execute(() -> db.weightDao().deleteWeight(entry)));
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightRecyclerView.setAdapter(adapter);

        // loads all entries from the database and populates the list
        // just calls getAllWeights() and dumps everything into the ArrayList
        DbExecutors.io().execute(() -> {
            List<WeightEntry> entriesFromDb = db.weightDao().getAllWeights();
            runOnUiThread(() -> {
                weightEntries.clear();
                weightEntries.addAll(entriesFromDb);
                adapter.notifyDataSetChanged();
            });
        });

        // add entry button pops up an AlertDialog
        addEntryButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.add_weight_title));

            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            builder.setView(input);

            builder.setPositiveButton(getString(R.string.save), (dialog, which) -> {
                // only checks if empty - no bounds checking, no try-catch for NumberFormatException
                // a user could type -50 or 9999 and it would save
                String weightText = input.getText().toString();
                if (!weightText.isEmpty()) {
                    double weight = Double.parseDouble(weightText);
                    // saves with today's date
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                    WeightEntry newEntry = new WeightEntry(date, weight);
                    DbExecutors.io().execute(() -> {
                        db.weightDao().insertWeight(newEntry);
                        List<WeightEntry> updated = db.weightDao().getAllWeights();

                        // hardcoded goal weight - this is a magic number
                        // the only comment in the entire project is this TODO that was never addressed
                        // CS 360 spec required a goal weight TABLE but it was never created
                        double goalWeight = 150.0; // TODO: externalize user goal persistence
                        // uses == on a double which has floating point precision issues
                        // also just shows a Toast, never actually sends an SMS
                        if (weight == goalWeight && ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            runOnUiThread(() -> Toast.makeText(this, getString(R.string.weight_goal_reached), Toast.LENGTH_LONG).show());
                        }

                        runOnUiThread(() -> {
                            weightEntries.clear();
                            weightEntries.addAll(updated);
                            adapter.notifyDataSetChanged();
                        });
                    });
                }
            });

            builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.cancel());
            builder.show();
        });

        // button to go to SMS permission screen
        smsPermissionButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataGridActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }
    // no edit or update method anywhere in this file
    // CS 360 rubric required update functionality but it was never implemented
}