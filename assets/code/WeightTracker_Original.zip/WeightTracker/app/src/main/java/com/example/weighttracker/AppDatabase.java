package com.example.weighttracker;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// only two entities listed here - CS 360 spec required three tables (users, weights, goals)
// the goal weight table was never created
@Database(entities = {User.class, WeightEntry.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // singleton with double-checked locking and volatile - this part is actually solid
    private static volatile AppDatabase INSTANCE;

    public abstract UserDao userDao();
    public abstract WeightDao weightDao();
    // no goalDao() - there's no Goal entity anywhere in the project

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "weight_tracker_db"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}